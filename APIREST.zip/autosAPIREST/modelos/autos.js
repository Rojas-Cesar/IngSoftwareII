//importar la biblioteca
var mongoose = require('mongoose');
//iniciar el constructor
var Schema = mongoose.Schema;

var AutoSchema = {
  marca: String,
  submarca: String,
  color: String,
  caballos: Number,
  modelo: Number,
  segmento: String
};



//crea una instancia
module.export = mongoose.model('Autos', AutoSchema);
