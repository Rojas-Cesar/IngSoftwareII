var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var Pelicula = require('../modelos/peliculas');

/* GET users listing. */
router.get('/', function(req, res, next) {

  Pelicula.find({} , (err, datos) => {
    if(err) {
      //re.json({'error' : 'Ocurrio un error al hacer la consulta'})
      res.send("<img src=\"https://images.wallpapersden.com/image/download/cyborg-cyberpunk-2077-digital-fan-art_bGllaGWUmZqaraWkpJRnamtlrWZrZWU.jpg\" alt= \"Italian Trulli\">");
    } else {
      res.status(200).json(datos);
      //res.send("<img src=\"https://images.wallpapersden.com/image/download/cyborg-cyberpunk-2077-digital-fan-art_bGllaGWUmZqaraWkpJRnamtlrWZrZWU.jpg\" alt= \"Italian Trulli\">");
    }
  });
});

router.post('/', (req, res, next) => {
  var peli = Pelicula({
    id : req.body.id,
    titulo : req.body.titulo,
    protagonista : req.body.protagonista,
    anio : req.body.aestreno,
    director : req.body.direc,
    cartel : req.body.foto
  });
  peli.save((err, data) => {
    if(err) {
      res.json({ 'error' : "Error al insertar"});
    } else {
      res.status(200).json(data);
    }
  });
});

router.get('/:idPeli', function(req, res, next) {

  Pelicula.findOne({'id':req.params.idPeli} , (err, datos) => {
    if(err) {
      //re.json({'error' : 'Ocurrio un error al hacer la consulta'})
      res.send("<img src=\"https://images.wallpapersden.com/image/download/cyborg-cyberpunk-2077-digital-fan-art_bGllaGWUmZqaraWkpJRnamtlrWZrZWU.jpg\" alt= \"Italian Trulli\">");
    } else {
      res.status(200).json(datos);
      //res.send("<img src=\"https://images.wallpapersden.com/image/download/cyborg-cyberpunk-2077-digital-fan-art_bGllaGWUmZqaraWkpJRnamtlrWZrZWU.jpg\" alt= \"Italian Trulli\">");
    }
  });
});

router.delete('/:idPeli', (req, res, next) => {
  Pelicula.deleteOne({'id':req.params.idPeli}, (err) => {
    if(err) {
      res.send("<img src=\"https://images.wallpapersden.com/image/download/cyborg-cyberpunk-2077-digital-fan-art_bGllaGWUmZqaraWkpJRnamtlrWZrZWU.jpg\" alt= \"Italian Trulli\">");
    } else {
      res.json({'mensaje':'OK'});
    }
  });
});


module.exports = router;
